Cautions When Using DXF Data                                   Last Update 2016.08.25

1. Copyright, ownership
TDK and TDK-Lambda retain the copyright and all other rights to this DXF data.

2. Duplication / distribution prohibition
This DXF data may only be used within your company. It is strictly prohibited to duplicate (including duplication after partial revision) and provide it to outside third parties.

3. Limitation of liability
�E While we have taken every precaution to ensure that this site operates properly, the accuracy and utility of these drawings carry no guarantee under law, and we assume no legal obligation or liability.
�E The creator is responsible for checking any drawing created using this DXF data (including computer graphics images).
�E We assume no liability for any problems or losses incurred through the use of this DXF data, including any damages or financial losses.

4. Changes, Deletions, Simplifications
�E Note that the contents of this site may be changed or deleted without prior notification.
�E Part of DXF data is simplified.

5. Prior to adoption of our Power Line EMC Filters, contact us for the "Delivery Specifications".


< Technical Support Contact Information >

�E Noise Filter
Email: nf_tech@jp.tdk-lambda.com


   Copyright (C) 2016 TDK-Lambda Corporation 
